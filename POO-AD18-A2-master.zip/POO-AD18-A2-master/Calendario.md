# Calendario POO Agosto-Diciembre 2018 Grupo A2


| S  | Fecha    | Actividad                                              |
|----|----------|--------------------------------------------------------|
| 1  | 06/08/18 | ¿Artistas que Programan?                               |
| 2  | 09/08/18 | Processing: forma y color                              |
| 3  | 13/08/18 | Processing: estructura y organización                  |
| 4  | 16/08/18 | Fundamentos de OOP / especificación Proyecto 1         |
|    | 20/08/18 | NO HAY SESIÓN: Lectura 1                               |
|    | 23/08/18 | NO HAY SESIÓN: Lectura 2                               |
|    | 27/08/18 | NO HAY SESIÓN: Lectura 3                               |
| 5  | 30/08/18 | Fundamentos de OOP / Interacción                       |
| 6  | 03/09/18 | Práctica 1: partículas 1 / Concepto Inicial Proyecto 1 |
| 7  | 06/09/18 | Patrones y relaciones.                                 |
| 8  | 10/09/18 | Práctica 2: partículas 2 / Límite cambios Proyecto 1   |
| 9  | 13/09/18 | Texto y sonido                                         |
| 10 | 17/09/18 | Intro a box 2D / Entrega Proyecto 1                    |
| 11 | 20/09/18 | Postmortem Proyecto 1 / Especificación Proyecto 2      |
| 12 | 24/09/18 | Box 2D                                                 |
| 13 | 27/09/18 | Práctica 3: box 2D / Concepto inicial proyecto 2       |
| 14 | 01/10/18 | Mapas de Bits                                          |
| 15 | 04/10/18 | Práctica 4: box 2D / Límite cambios Proyecto 2         |
| 16 | 08/10/18 | Recursividad / Entrega Proyecto 2                      |
| 17 | 11/10/18 | postmortem Proyecto 2 / OOP avanzado                   |
| 18 | 15/10/18 | OOP avanzado / especificación Proyecto 3               |
| 19 | 18/10/18 | práctica 5:  geometría / Concepto Inicial Proyecto 3   |
| 20 | 22/10/18 | práctica 6: geometría / Límite cambios proyecto 3      |
| 21 | 25/10/18 | Video / Entrega Proyecto 3 / especificación Proyecto 4 |
| 22 | 29/10/18 | Postmortem Proyecto 3 / OpenCV                         |
| 23 | 01/11/18 | practica 7: video / Concepto inicial proyecto 4        |
| 24 | 05/11/18 | OpenCV                                                 |
| 25 | 08/11/18 | práctica 8: OpenCV / Límite cambios Proyecto 4         |
| 27 | 12/11/18 | 3D                                                     |
| 28 | 15/11/18 | p5.js/ Entrega proyecto 4 / especificación Proyecto 5  |
| 29 | 19/11/18 | ASUETO                                                 |
| 30 | 22/11/18 | Postmortem proyecto 4                                  |
| 31 | 26/11/18 | práctica 9: p5.js / Concepto inicial Proyecto 5        |
| 32 | 29/11/18 | Unity                                                  |
| 33 | 03/12/18 | Límite cambios Proyecto 5                              |
| 34 | 06/12/18 | Entrega y presentación de proyecto 5                   |
